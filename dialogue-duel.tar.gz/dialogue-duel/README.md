# Dialogue Duel

Pick a scene, recreate it on camera, get scored against the original, and challenge others.

## Run it

    cd dialogue-duel
    node server.js              # needs Node 18+, no npm install
    # open http://localhost:3000

Optional environment variables:

| Variable | What it does |
| --- | --- |
| `PORT` | Port to listen on (default 3000) |
| `DATA_DIR` | Where videos and `db.json` are stored (default `./data`) |
| `ANTHROPIC_API_KEY` | Turns on AI scene scoring (framing, costume, pose, expression). Without it the app uses basic frame matching |
| `ANTHROPIC_MODEL` | Model used for scoring (default `claude-sonnet-5-5`) |
| `AUTH_METHODS` | Sign-in methods: `email`, `phone` or `email,phone`. Leave empty for name-only sign-in (development only) |
| `RESEND_API_KEY`, `MAIL_FROM` | Sends email codes through Resend |
| `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM` (or `TWILIO_MESSAGING_SERVICE_SID`) | Sends phone codes by SMS through Twilio |
| `DEFAULT_COUNTRY_CODE` | Added to 10-digit phone numbers (default `91`) |
| `SMS_DAILY_CAP` | Most SMS codes sent per day (default 500), so abuse cannot run up your bill |
| `AUTH_IP_LIMIT` | Code requests allowed per IP per minute (default 20 for email, 10 for phone) |
| `ADMIN_TOKEN` | Lets you remove any clip or take by sending the `x-admin-token` header |

Camera recording needs **https** (or localhost). Put it behind a host that provides TLS (Render, Fly.io, Railway, a VPS with Caddy).

## Sign-in

Users sign in with a one-time 6-digit code sent to their **email or phone**, and choose which at sign-in. There are no passwords. A code works for 10 minutes and allows 5 tries. The same email or number signs into the same account on any device.

With `AUTH_METHODS` empty the app uses name-only sign-in so you can try it locally. In development, with email or phone on but no provider keys set, codes print in the server console instead of being sent.

## How it works

1. **Recreate.** Open a clip, tap Recreate, and record with the original shown as a ghost overlay or side by side. Or upload a video you made elsewhere.
2. **Score.** The browser pulls 4 frames and an audio-energy curve from your video and uploads it. The server compares them with the original's: scene and acting through AI (or basic frame matching), delivery through audio timing and rhythm. Score = 60% visual, 40% delivery.
3. **Public score.** Anyone signed in can rate a take 1 to 10, react with emoji and comment. From 3 ratings on, the ranking uses 50% AI and 50% public score.
4. **Featured.** The home page shows top takes, top creators and a creator of the week, and hot clips by takes this week.
5. **Share.** Download the video, share it through the phone's share sheet (to Instagram, WhatsApp and so on), or copy a challenge link that opens the same clip with "beat this score".

## Limits to know about

- Scoring is an estimate. It does not transcribe speech, so it cannot check exact words.
- One account per email or phone number. Anyone can still own several numbers, so treat scores as fun, not as proof, until you add stronger checks.
- Email and phone are stored only as one-way hashes, so you cannot contact users or recover an account if someone loses their number.
- Data lives in one JSON file and local disk. Move to Postgres and object storage (S3, R2) when you have real traffic.
- 3 reports hide a clip automatically. Add a takedown address and a DMCA process before you go public.
